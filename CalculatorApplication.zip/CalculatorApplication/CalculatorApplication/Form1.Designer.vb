﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button_Dot = New System.Windows.Forms.Button()
        Me.Button_Plus = New System.Windows.Forms.Button()
        Me.Button0 = New System.Windows.Forms.Button()
        Me.Button_Sub = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button_Mul = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button_Division = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button_Clear = New System.Windows.Forms.Button()
        Me.Button_Equal = New System.Windows.Forms.Button()
        Me.TxtOutput = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(12, 47)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(42, 33)
        Me.Button7.TabIndex = 0
        Me.Button7.Text = "7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button_Dot
        '
        Me.Button_Dot.Location = New System.Drawing.Point(156, 164)
        Me.Button_Dot.Name = "Button_Dot"
        Me.Button_Dot.Size = New System.Drawing.Size(42, 33)
        Me.Button_Dot.TabIndex = 13
        Me.Button_Dot.Text = "."
        Me.Button_Dot.UseVisualStyleBackColor = True
        '
        'Button_Plus
        '
        Me.Button_Plus.Location = New System.Drawing.Point(108, 164)
        Me.Button_Plus.Name = "Button_Plus"
        Me.Button_Plus.Size = New System.Drawing.Size(42, 33)
        Me.Button_Plus.TabIndex = 14
        Me.Button_Plus.Text = "+"
        Me.Button_Plus.UseVisualStyleBackColor = True
        '
        'Button0
        '
        Me.Button0.Location = New System.Drawing.Point(12, 164)
        Me.Button0.Name = "Button0"
        Me.Button0.Size = New System.Drawing.Size(90, 33)
        Me.Button0.TabIndex = 15
        Me.Button0.Text = "0"
        Me.Button0.UseVisualStyleBackColor = True
        '
        'Button_Sub
        '
        Me.Button_Sub.Location = New System.Drawing.Point(156, 125)
        Me.Button_Sub.Name = "Button_Sub"
        Me.Button_Sub.Size = New System.Drawing.Size(42, 33)
        Me.Button_Sub.TabIndex = 16
        Me.Button_Sub.Text = "-"
        Me.Button_Sub.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(108, 125)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(42, 33)
        Me.Button3.TabIndex = 17
        Me.Button3.Text = "3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(60, 125)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(42, 33)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 125)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(42, 33)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button_Mul
        '
        Me.Button_Mul.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Mul.Location = New System.Drawing.Point(156, 86)
        Me.Button_Mul.Name = "Button_Mul"
        Me.Button_Mul.Size = New System.Drawing.Size(42, 33)
        Me.Button_Mul.TabIndex = 20
        Me.Button_Mul.Text = "*"
        Me.Button_Mul.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button_Mul.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(108, 86)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(42, 33)
        Me.Button6.TabIndex = 21
        Me.Button6.Text = "6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(60, 86)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(42, 33)
        Me.Button5.TabIndex = 22
        Me.Button5.Text = "5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(12, 86)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(42, 33)
        Me.Button4.TabIndex = 23
        Me.Button4.Text = "4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button_Division
        '
        Me.Button_Division.Location = New System.Drawing.Point(156, 47)
        Me.Button_Division.Name = "Button_Division"
        Me.Button_Division.Size = New System.Drawing.Size(42, 33)
        Me.Button_Division.TabIndex = 24
        Me.Button_Division.Text = "/"
        Me.Button_Division.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(108, 47)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(42, 33)
        Me.Button9.TabIndex = 25
        Me.Button9.Text = "9"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(60, 47)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(42, 33)
        Me.Button8.TabIndex = 26
        Me.Button8.Text = "8"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button_Clear
        '
        Me.Button_Clear.Location = New System.Drawing.Point(204, 47)
        Me.Button_Clear.Name = "Button_Clear"
        Me.Button_Clear.Size = New System.Drawing.Size(42, 33)
        Me.Button_Clear.TabIndex = 27
        Me.Button_Clear.Text = "C"
        Me.Button_Clear.UseVisualStyleBackColor = True
        '
        'Button_Equal
        '
        Me.Button_Equal.Location = New System.Drawing.Point(204, 86)
        Me.Button_Equal.Name = "Button_Equal"
        Me.Button_Equal.Size = New System.Drawing.Size(42, 111)
        Me.Button_Equal.TabIndex = 29
        Me.Button_Equal.Text = "="
        Me.Button_Equal.UseVisualStyleBackColor = True
        '
        'TxtOutput
        '
        Me.TxtOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtOutput.Location = New System.Drawing.Point(12, 12)
        Me.TxtOutput.Name = "TxtOutput"
        Me.TxtOutput.Size = New System.Drawing.Size(234, 29)
        Me.TxtOutput.TabIndex = 30
        Me.TxtOutput.Text = "0"
        Me.TxtOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(263, 210)
        Me.Controls.Add(Me.TxtOutput)
        Me.Controls.Add(Me.Button_Equal)
        Me.Controls.Add(Me.Button_Clear)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button_Division)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button_Mul)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button_Sub)
        Me.Controls.Add(Me.Button0)
        Me.Controls.Add(Me.Button_Plus)
        Me.Controls.Add(Me.Button_Dot)
        Me.Controls.Add(Me.Button7)
        Me.Name = "form1"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button7 As Button
    Friend WithEvents Button_Dot As Button
    Friend WithEvents Button_Plus As Button
    Friend WithEvents Button0 As Button
    Friend WithEvents Button_Sub As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button_Mul As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button_Division As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button_Clear As Button
    Friend WithEvents Button_Equal As Button
    Friend WithEvents TxtOutput As TextBox
End Class
